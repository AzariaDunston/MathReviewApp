package com.example.p

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_settings.*

class MainActivity : AppCompatActivity() {
    var selectedMode = ""
    var selectedLevel = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        selectedMode = intent.getStringExtra("operationMode").toString()
        selectedLevel = intent.getStringExtra("difficultyLevel").toString()

        setMode.text = selectedMode
        setLevel.text = selectedLevel

        when (selectedMode) {
            "2131230791" ->
                setMode.text = "Addition"
            "2131231005" ->
                setMode.text = "Subtraction"
            "2131231038" ->
                setMode.text = "Multiplication"
            "2131230887" ->
                setMode.text = "Division"
            "null" -> {
                setMode.text = "Addition"
                selectedMode = "2131230791" }
            "" -> {
                setMode.text = "Addition"
                selectedMode = "2131230791" }
        }

        when (selectedLevel) {
            "2131230969" ->
                setLevel.text = "1"
            "2131230970" ->
                setLevel.text = "2"
            "2131230971" ->
                setLevel.text = "3"
            "null" -> {
                setLevel.text = "1"
                selectedLevel = "2131230969"}
            "" -> {
                setLevel.text = "1"
                selectedLevel = "2131230969"}

        }

    }

    fun go2SettingsActivity(view: View){
        val intent = Intent(this, SettingsActivity::class.java)
        intent.putExtra("operationMode", selectedMode)
        intent.putExtra("difficultyLevel", selectedLevel)
        startActivity(intent)
    }

    fun go2QuizActivity(view: View){
        val intent = Intent(this, QuizActivity::class.java)
        intent.putExtra("operationMode", selectedMode)
        intent.putExtra("difficultyLevel", selectedLevel)
        startActivity(intent)
    }

    fun go2LessonActivity(view: View){
        val intent = Intent(this, LessonActivity::class.java)
        intent.putExtra("operationMode", selectedMode)
        intent.putExtra("difficultyLevel", selectedLevel)
        startActivity(intent)
    }

}