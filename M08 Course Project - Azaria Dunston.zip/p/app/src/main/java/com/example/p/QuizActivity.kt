package com.example.p

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import kotlinx.android.synthetic.main.activity_quiz.*
import kotlin.random.Random


class QuizActivity : AppCompatActivity() {
    var selectedMode = ""
    var selectedLevel = ""

    var rightAnswer = "Yes!"
    var strikes = 0
    private val quizLength = 5
    private var questionNum = -1
    //questionNum keeps track of how many questions have been answered correctly

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quiz)

        selectedMode = intent.getStringExtra("operationMode").toString()
        selectedLevel = intent.getStringExtra("difficultyLevel").toString()

        rightAnswer = "Yes!"
        strikes = 0
        questionNum = -1


    }

    fun checkAnswer(view: View) {
        var selectedButton = findViewById<View>(view.id) as Button
        var selectedAnswer = selectedButton.text.toString()

        if (selectedAnswer != rightAnswer) {
            strikes += 1
            tryAgain.text = "Nope! try again"
        }
        else if (selectedAnswer == rightAnswer) {
            questionNum += 1
            question.text = "Good"
            tryAgain.text = " "


            if (questionNum == quizLength){
                go2GradeActivity()
            }
            else {
                when (selectedMode) {
                    "2131230791" ->
                        rightAnswer = additionQuestion()
                    "2131231005" ->
                        rightAnswer = subtractionQuestion()
                    "2131231038" ->
                        rightAnswer = multiplicationQuestion()
                    "2131230887" ->
                        rightAnswer = divisionQuestion()
                    "null" -> {
                        rightAnswer = additionQuestion()
                        selectedMode = "2131230791" }
                    "" -> {
                        rightAnswer = additionQuestion()
                        selectedMode = "2131230791" }
                }
            }
        }



    }

    private fun additionQuestion(): String {
        var num1= Random.nextInt(0, 10)
        var num2= Random.nextInt(0, 10)
        var newAnswer = num1 + num2

        when (selectedLevel) {
            "2131230969" -> {
                 num1= Random.nextInt(0, 10)
                 num2= Random.nextInt(0, 10)
                 newAnswer = num1 + num2

                answer1.text = Random.nextInt(0, 10).toString()
                answer2.text = newAnswer.toString()
                answer3.text = Random.nextInt(0, 10).toString()
                answer4.text = Random.nextInt(0, 10).toString()}
            "2131230970" -> {
                num1 = Random.nextInt(10, 20)
                num2= Random.nextInt(10, 20)
                newAnswer = num1 + num2

                answer1.text = Random.nextInt(10, 40).toString()
                answer2.text = newAnswer.toString()
                answer3.text = Random.nextInt(10, 40).toString()
                answer4.text = Random.nextInt(10, 40).toString()}
            "2131230971" ->{
                num1 = Random.nextInt(100, 120)
                num2= Random.nextInt(100, 120)
                newAnswer= num1 + num2

                answer1.text = Random.nextInt(100, 120).toString()
                answer2.text = newAnswer.toString()
                answer3.text = Random.nextInt(100, 120).toString()
                answer4.text = Random.nextInt(100, 120).toString()}
            "null" -> {
                num1 = Random.nextInt(0, 10)
                num2= Random.nextInt(0, 10)
                newAnswer = num1 + num2
                selectedLevel = "2131230969"

                answer1.text = Random.nextInt(0, 10).toString()
                answer2.text = newAnswer.toString()
                answer3.text = Random.nextInt(0, 10).toString()
                answer4.text = Random.nextInt(0, 10).toString()}
            "" -> {
                num1 = Random.nextInt(0, 10)
                num2= Random.nextInt(0, 10)
                newAnswer = num1 + num2
                selectedLevel = "2131230969"

                answer1.text = Random.nextInt(0, 10).toString()
                answer2.text = newAnswer.toString()
                answer3.text = Random.nextInt(0, 10).toString()
                answer4.text = Random.nextInt(0, 10).toString()}
        }


        question.text = "$num1 + $num2 = _"
        return newAnswer.toString();
    }



    private fun subtractionQuestion(): String {
        var num1 = Random.nextInt(0, 10)
        var num2 = Random.nextInt(0, 10)
        var newAnswer = num1 - num2

        when (selectedLevel) {
            "2131230969" -> {
                num1= Random.nextInt(0, 10)
                num2= Random.nextInt(0, (num1+1))
                newAnswer = num1 - num2

                answer1.text = Random.nextInt(0, 10).toString()
                answer2.text = newAnswer.toString()
                answer3.text = Random.nextInt(0, 10).toString()
                answer4.text = Random.nextInt(0, 10).toString()}
            "2131230970" -> {
                num1 = Random.nextInt(10, 20)
                num2= Random.nextInt(10, (num1+1))
                newAnswer = num1 - num2

                answer1.text = Random.nextInt(5, 20).toString()
                answer2.text = newAnswer.toString()
                answer3.text = Random.nextInt(5, 20).toString()
                answer4.text = Random.nextInt(5, 20).toString()}
            "2131230971" ->{
                num1 = Random.nextInt(100, 120)
                num2= Random.nextInt(100, (num1+1))
                newAnswer= num1 - num2

                answer1.text = Random.nextInt(10, 120).toString()
                answer2.text = newAnswer.toString()
                answer3.text = Random.nextInt(10, 120).toString()
                answer4.text = Random.nextInt(10, 120).toString()}
            "null" -> {
                num1 = Random.nextInt(0, 10)
                num2= Random.nextInt(0, (num1+1))
                newAnswer = num1 - num2
                selectedLevel = "2131230969"

                answer1.text = Random.nextInt(0, 10).toString()
                answer2.text = newAnswer.toString()
                answer3.text = Random.nextInt(0, 10).toString()
                answer4.text = Random.nextInt(0, 10).toString()}
            "" -> {
                num1 = Random.nextInt(0, 10)
                num2= Random.nextInt(0, (num1+1))
                newAnswer = num1 - num2
                selectedLevel = "2131230969"

                answer1.text = Random.nextInt(0, 10).toString()
                answer2.text = newAnswer.toString()
                answer3.text = Random.nextInt(0, 10).toString()
                answer4.text = Random.nextInt(0, 10).toString()}
        }

        question.text = "$num1 - $num2 = _"
        return newAnswer.toString();
    }

    private fun multiplicationQuestion(): String {
        var num1 = Random.nextInt(0, 5)
        var num2= Random.nextInt(0, 5)
        var newAnswer = num1 * num2

        when (selectedLevel) {
            "2131230969" -> {
                num1= Random.nextInt(0, 5)
                num2= Random.nextInt(0, 5)
                newAnswer = num1 * num2

                answer1.text = Random.nextInt(0, 15).toString()
                answer2.text = newAnswer.toString()
                answer3.text = Random.nextInt(0, 15).toString()
                answer4.text = Random.nextInt(0, 15).toString()}
            "2131230970" -> {
                num1 = Random.nextInt(10, 20)
                num2= Random.nextInt(10, 20)
                newAnswer = num1 * num2

                answer1.text = Random.nextInt(100, 400).toString()
                answer2.text = newAnswer.toString()
                answer3.text = Random.nextInt(100, 400).toString()
                answer4.text = Random.nextInt(100, 400).toString()}
            "2131230971" ->{
                num1 = Random.nextInt(100, 120)
                num2= Random.nextInt(100, 120)
                newAnswer= num1 * num2

                answer1.text = Random.nextInt(1000, 1200).toString()
                answer2.text = newAnswer.toString()
                answer3.text = Random.nextInt(1000, 1200).toString()
                answer4.text = Random.nextInt(1000, 1200).toString()}
            "null" -> {
                num1 = Random.nextInt(0, 5)
                num2= Random.nextInt(0, 5)
                newAnswer = num1 * num2
                selectedLevel = "2131230969"

                answer1.text = Random.nextInt(0, 15).toString()
                answer2.text = newAnswer.toString()
                answer3.text = Random.nextInt(0, 15).toString()
                answer4.text = Random.nextInt(0, 15).toString()}
            "" -> {
                num1 = Random.nextInt(0, 5)
                num2= Random.nextInt(0, 5)
                newAnswer = num1 * num2
                selectedLevel = "2131230969"

                answer1.text = Random.nextInt(0, 15).toString()
                answer2.text = newAnswer.toString()
                answer3.text = Random.nextInt(0, 15).toString()
                answer4.text = Random.nextInt(0, 15).toString()}
        }

        question.text = "$num1 * $num2 = _"
        return newAnswer.toString();
    }

    //CRASH WARNING: Crashes on the third question
    private fun divisionQuestion(): String {
        var num1 = Random.nextInt(0, 10)
        var num2 = Random.nextInt(0, 10)
        var newAnswer = num1 / num2

        when (selectedLevel) {
            "2131230969" -> {
                num1= Random.nextInt(0, 10)
                num2= Random.nextInt(0, 10)
                newAnswer = num1 / num2

                answer1.text = Random.nextInt(0, 10).toString()
                answer2.text = newAnswer.toString()
                answer3.text = Random.nextInt(0, 10).toString()
                answer4.text = Random.nextInt(0, 10).toString()}
            "2131230970" -> {
                num1 = Random.nextInt(10, 50)
                num2= Random.nextInt(10, 50)
                newAnswer = num1 / num2

                answer1.text = Random.nextInt(5, 50).toString()
                answer2.text = newAnswer.toString()
                answer3.text = Random.nextInt(5, 50).toString()
                answer4.text = Random.nextInt(5, 50).toString()}
            "2131230971" ->{
                num1 = Random.nextInt(100, 300)
                num2= Random.nextInt(100, 300)
                newAnswer= num1 / num2

                answer1.text = Random.nextInt(10, 300).toString()
                answer2.text = newAnswer.toString()
                answer3.text = Random.nextInt(10, 300).toString()
                answer4.text = Random.nextInt(10, 300).toString()}
            "null" -> {
                num1 = Random.nextInt(0, 10)
                num2= Random.nextInt(0, 10)
                newAnswer = num1 / num2
                selectedLevel = "2131230969"

                answer1.text = Random.nextInt(0, 10).toString()
                answer2.text = newAnswer.toString()
                answer3.text = Random.nextInt(0, 10).toString()
                answer4.text = Random.nextInt(0, 10).toString()}
            "" -> {
                num1 = Random.nextInt(0, 10)
                num2= Random.nextInt(0, 10)
                newAnswer = num1 / num2
                selectedLevel = "2131230969"

                answer1.text = Random.nextInt(0, 10).toString()
                answer2.text = newAnswer.toString()
                answer3.text = Random.nextInt(0, 10).toString()
                answer4.text = Random.nextInt(0, 10).toString()}
        }

        question.text = "$num1 / $num2 = _"
        return newAnswer.toString();
    }

    private fun go2GradeActivity(){
        val intent = Intent(this, GradeActivity::class.java)
        intent.putExtra("operationMode", selectedMode) //Int
        intent.putExtra("difficultyLevel", selectedLevel) //Int
        intent.putExtra("numGotWrong", strikes.toString()) //Int
        intent.putExtra("quizLength", quizLength.toString()) //Int
        startActivity(intent)
    }

    fun go2MainActivity(view: View){
        val intent = Intent(this, MainActivity::class.java)
        intent.putExtra("operationMode", selectedMode) //Int
        intent.putExtra("difficultyLevel", selectedLevel) //Int
        startActivity(intent)
    }
}