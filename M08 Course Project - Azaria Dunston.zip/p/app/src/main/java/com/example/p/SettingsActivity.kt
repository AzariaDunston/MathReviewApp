package com.example.p

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.RadioButton
import kotlinx.android.synthetic.main.activity_settings.*

class SettingsActivity : AppCompatActivity() {
    /** addition - 2131231227
     *  subtraction - 2131231232
     *  multiplication - 2131231233
     *  division - 2131231228 */

    /** single digit - 2131231229
     *  double digit - 2131231230
     *  triple digit - 2131231231
     */

    var mode = ""
    var level = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        mode = intent.getStringExtra("operationMode").toString()
        level = intent.getStringExtra("difficultyLevel").toString()

       when (mode) {
            "2131230791" ->
                addMode.isChecked = true
            "2131231005" ->
                minusMode.isChecked = true
            "2131231038" ->
                multiplyMode.isChecked = true
            "2131230887" ->
                divideMode.isChecked = true
            "null" -> {
                mode = "2131230791"
                addMode.isChecked = true
            }
        }

        when (level) {
            "2131230969" ->
                level1.isChecked = true
            "2131230970" ->
                level2.isChecked = true
            "2131230971" ->
                level3.isChecked = true
            "null" -> {
                level = "2131230969"
                level1.isChecked = true
            }
        }

        //textView3.text = mode

    }

    fun modeSelected(view: View){

        if (view is RadioButton) {
            // Is the button now checked?
            val checked = view.isChecked

            // Check which radio button was clicked
            when (view.getId()) {
                R.id.addMode ->
                    if (checked) {
                        mode = addMode.id.toString()
                    }
                R.id.minusMode ->
                    if (checked) {
                        mode = minusMode.id.toString()
                    }
                R.id.multiplyMode ->
                    if (checked) {
                        mode = multiplyMode.id.toString()
                    }
                R.id.divideMode ->
                    if (checked) {
                        mode = divideMode.id.toString()
                    }
            }
        }
        //textView3.text = mode.toString()
    }

    fun levelSelected(view: View) {

        if (view is RadioButton) {
            // Is the button now checked?
            val checked = view.isChecked

            // Check which radio button was clicked
            when (view.getId()) {
                R.id.level1 ->
                    if (checked) {
                        level = level1.id.toString()
                    }
                R.id.level2 ->
                    if (checked) {
                        level = level2.id.toString()
                    }
                R.id.level3 ->
                    if (checked) {
                        level = level3.id.toString()
                    }
            }
        }
        //textView3.text = level.toString()
    }

    fun go2MainActivity(view: View){
        val intent = Intent(this, MainActivity::class.java)
        intent.putExtra("operationMode", mode) //Int
        intent.putExtra("difficultyLevel", level) //Int
        startActivity(intent)
    }
}