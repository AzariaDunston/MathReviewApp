package com.example.p

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_lesson.*

class LessonActivity : AppCompatActivity() {
    var selectedMode = ""
    var selectedLevel = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lesson)

        selectedMode = intent.getStringExtra("operationMode").toString()
        selectedLevel = intent.getStringExtra("difficultyLevel").toString()


        var add_Lesson = "Addition is when you add numbers together and get a bigger number. For example, let's add 3 to 2. " +
                "To do that, we'd count to 3: 1, 2, 3. Then we would count 2 numbers past 3: " +
                "1, 2, 3, 4 ,5. So 3 + 2 = 5."
        var minus_Lesson = "Subtraction is when you take numbers from each other and get a smaller number. For example, let's subtract 3 to 2. " +
                "To do that, we'd count to 3: 1, 2, 3. Then we would take away the last 2 numbers, which leaves us with: 1. " +
                "So 3 - 2 = 1."
        var multiply_Lesson = "Multiplication is when you take a number and add it to itself a certain number of times. For example, let's multiply 2 by 3. " +
                "To do that, we'd count to 2 once: 1, 2. Then, since we are multiplying by 3, not 1, we'd count 2 numbers further: 3, 4. " +
                "Then 2 numbers further for the third time: 5, 6. In total, we've counted 2 numbers 3 times and got to 6. So 2 * 3 = 6."
        var divide_Lesson = "Division is when you see how many of one number can fit into another. For example, Let's divide 7 by 2. " +
                "To do that, we'd count to 7, but after every time we count 2 numbers, we'll say 'then' as a sort of marker: " +
                "1, 2, then, 3, 4, then, 5, 6, then, 7. Now we will count how many 'then's there are. There are 3. So 7 / 2 = 3."

        when (selectedMode) {
            "2131230791" -> {
                lessonTitle.text = "A Quick Lesson on Addition"
                theLesson.text = add_Lesson }
            "2131231005" -> {
                lessonTitle.text = "A Quick Lesson on Subtraction"
                theLesson.text = minus_Lesson }
            "2131231038" -> {
                lessonTitle.text = "A Quick Lesson on Multiplication"
                theLesson.text = multiply_Lesson }
            "2131230887" -> {
                lessonTitle.text = "A Quick Lesson on Subtraction"
                theLesson.text = divide_Lesson }
            "null" -> {
                lessonTitle.text = "A Quick Lesson on Addition"
                selectedMode = "2131230791"
                theLesson.text = add_Lesson }
        }

    }

    fun go2MainActivity(view: View){
        val intent = Intent(this, MainActivity::class.java)
        intent.putExtra("operationMode", selectedMode) //Int
        intent.putExtra("difficultyLevel", selectedLevel) //Int
        startActivity(intent)
    }
}